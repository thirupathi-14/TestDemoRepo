package StepDefinitions;

import org.testng.Assert;

import PageObjects.DashboardPage;
import PageObjects.LoginPage;
import Utilities.TestContext;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class DashboardSteps {

	TestContext testContext;
	DashboardPage dashboardPage;

	public DashboardSteps(TestContext context) {
		testContext = context;
		dashboardPage = testContext.getPageObjectManager().getDashboardPage();
	}
	
	@Then("Click On Dashboard Menu")
	public void clickOnDashboardMenu() throws InterruptedException {
		
		dashboardPage.clickOnDashbordMenu();
	}
	
	@Then("Click On Add New")
	public void clickOnaddNew() throws InterruptedException {
		
		dashboardPage.clickOnaddNew();
	}
	
	@Then("Click On Dashboard New Event")
	public void clickOnDashboardNewEvent() throws InterruptedException {
		
		dashboardPage.clickOnDashboradNewEvent();
	}

}
