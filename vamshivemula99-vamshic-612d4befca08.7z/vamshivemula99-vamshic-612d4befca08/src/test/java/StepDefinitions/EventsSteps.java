package StepDefinitions;

import org.testng.Assert;

import Utilities.TestContext;
import io.cucumber.java.en.Given;
import PageObjects.EventsPage;
import PageObjects.LoginPage;
import Utilities.TestContext;
import Utilities.Wait;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EventsSteps {
	TestContext testContext;
	EventsPage eventsPage;
	public EventsSteps(TestContext context) {
		testContext = context;
		eventsPage = testContext.getPageObjectManager().getEventsPage();
	}

	@Given("Click On New Event Button")
	public void clickOnNewEventButton() {
		
		eventsPage.clickNeweventsSlip();
	}
	
	@Then("Click On Events Menu")
	public void clickOnEventMenu() {
		
		eventsPage.clickOnEventsMenu();
	}
	@Then("Click On Apply Button")
	public void clickOnApplyButton() throws InterruptedException {
		
		eventsPage.clickOnApplyButton();
	}
	
	@Then("Click On Fillter Apply Button")
	public void clickOnFillterApplyButton() throws InterruptedException {
		
		eventsPage.clickOnFillterApplyButton();
	}
	
	
	@Then("Select Date")
	public void selectDate() throws InterruptedException {
		
		eventsPage.selectDate();
	}
	
	@Then("Select 2daystDate")
	public void selec2daystDate() throws InterruptedException {
		
		eventsPage.selec2daystDate();
	}
	
	
	
	@Then("Filter and select OffCalendar")
	public void fillterAndSelectOffCalendar() throws InterruptedException {
		eventsPage.clickOnFiltters();
		eventsPage.clickOnFiltterStatusDropDown();
		eventsPage.selectOffCalendarCheckBox();
	}
	
	
	
	@Then("Verify NonRecurring Event Created.")
	public void verifyNonRecurringEvent()
	{
		String event=eventsPage.verifyNonReccuringEvent();
		if(event.equalsIgnoreCase("In ray with new matter, (100002), Demo description (vv3p)"))
		   {
			 Assert.assertEquals(event,"In ray with new matter, (100002), Demo description (vv3p)");
		   }
	}
	
	@Then("Verify NonRecurring Event OffCalendar Created.")
	public void verifyNonReccuringEventOffCalendar()
	{
		String event=eventsPage.verifyNonReccuringEventOffCalendar();
		if(event.equalsIgnoreCase("In ray with new matter, (100002), Off Calendar (vv3p)"))
		   {
			 Assert.assertEquals(event,"In ray with new matter, (100002), Off Calendar (vv3p)");
		   }
	}
	
	
	
	@Then("Enter Date And Time")
	public void enterDateAndTime() throws InterruptedException {
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
	}
	
	@Then("Select Duration")
	public void selectDuration() {
		
		eventsPage.enterDuration();
		
	}
	
	@Then("Select Matter")
	public void selectMatter() {
		
		eventsPage.selectMatter();
		
	}
	
	@Then("Select AssignedTo")
	public void selectAssigne() throws InterruptedException {
		
		eventsPage.selectAssignedToList();
		
	}
	
	@Then("Select Followres")
	public void selectFollowers() throws InterruptedException {
		
		eventsPage.selectfollowersList();
		
	}
	
	@Then("Enter Description")
	public void enterDescrption() throws InterruptedException {
		
		eventsPage.inputDescription();
		eventsPage.enterNotes();
		
	}
	
	@Then("Click On Save Button")
	public void clickOnSaveButton() throws InterruptedException {
		eventsPage.clickOnSaveButton();
		
	}
	
	@Then("Click On Event Link")
	public void clickOnEvenDescriptionLink() throws InterruptedException {
		eventsPage.clickOnEvenDescriptionLink();
		
	}
	
	@Then("Click On EventInprogress Link")
	public void clickOnEvenInprogressLink() throws InterruptedException {
		Thread.sleep(4000);
		eventsPage.clickOnEvenLink("InProgress");
		Thread.sleep(4000);
		
	}
	
	@Then("Click On welcome Link")
	public void clickOnEvenWelcomeLink() throws InterruptedException {
		Thread.sleep(4000);
		eventsPage.clickOnEvenLink("Welcome");
		Thread.sleep(4000);
		
	}
	@Then("Click On EventOffCalendar Link")
	public void clickOnEvenOffCalendarLink() throws InterruptedException {
		Thread.sleep(4000);
		eventsPage.clickOnEvenLink("Off Calendar");
		Thread.sleep(4000);
		
	}
	
	
	
	@Then("Click On Edit Button")
	public void clickOnEditButton() throws InterruptedException {
		eventsPage.clickOnEditButton();
		
	}
	
	@Then("Click On AditTrial Button")
	public void clickOnAditTrialButton() throws InterruptedException {
		eventsPage.clickOnAuditTrailButton();
		
	}
	
	@Then("Verify Event Creation")
	public void verifyEventCreation() throws InterruptedException {
		String event=eventsPage.verifyEditCreation();
		if(event.equalsIgnoreCase("Event Creation"))
		   {
			 Assert.assertEquals(event,"Event Creation");
		   }
		
	}
	
	@Then("Verify Event Updated Values")
	public void verifyEventUpdatedValues() throws InterruptedException {
		String eventCode=eventsPage.verifyUpdatedEventcode();
		if(eventCode.equalsIgnoreCase("ARB"))
		   {
			 Assert.assertEquals(eventCode,"ARB");
		   }
		
		String description=eventsPage.verifyUpdatedDescription();
		if(description.equalsIgnoreCase("Welcome"))
		   {
			 Assert.assertEquals(description,"Welcome");
		   }
		
	}
	
	
	
	@Then("Fill Necessary filed and Click on Save")
	public void fillNecessaryFiledsAndClickOnSave() throws InterruptedException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.inputDescription();
		eventsPage.enterNotes();
		eventsPage.clickOnSaveButton();
	}
	
	@Then("Fill Necessary filed and Click on Save With OneDay Reminder")
	public void fillNecessaryFiledsAndClickOnSaveWithOndeyReminder() throws InterruptedException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.clickOnRemindersDropDown();
		eventsPage.selectOneDay();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.inputDescription();
		eventsPage.enterNotes();
		eventsPage.clickOnSaveButton();
	}
	
	@Then("Fill Necessary filed and Click on Save With InProgress")
	public void fillNecessaryFiledsAndClickOnSaveWithInProgress() throws InterruptedException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.clickOnStatusDropDown();
		eventsPage.selectInProgress();
		eventsPage.inputDescription("InProgress");
		eventsPage.enterNotes();
		eventsPage.clickOnSaveButton();
	}
	
	@Then("Fill Necessary filed and Click on Save With OffCalender")
	public void fillNecessaryFiledsAndClickOnSaveWithOffCalender() throws InterruptedException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.clickOnStatusDropDown();
		eventsPage.selectOffCalendar();
		eventsPage.inputDescription("Off Calendar");
		eventsPage.enterNotes();
		eventsPage.clickOnSaveButton();
	}
	
	
	@Then("Fill Necessary filed and Click on Save with Update")
	public void fillNecessaryFiledsAndClickOnSaveWithUpdate() throws InterruptedException {
		
		eventsPage.selectEventCode("ARB");
		eventsPage.enter2DaysDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList(" vamshi3 v (vv3p) ");
		eventsPage.selectfollowersList(" vamshi3 v (vv3p) ");
		eventsPage.inputDescription("Welcome");
		eventsPage.enterNotes("Welcome");
		eventsPage.clickOnSaveButton();
	}
	
	


}
