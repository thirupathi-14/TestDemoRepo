package StepDefinitions;

import java.util.List;
import java.util.Map;

import org.testng.Assert;

import PageObjects.LoginPage;
import Utilities.TestContext;
import Utilities.Wait;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {

	TestContext testContext;
	LoginPage loginPage;

	public LoginSteps(TestContext context) {
		testContext = context;
		loginPage = testContext.getPageObjectManager().getLoginPage();
	}

	@Given("Launch Clarra Login page")
	public void launch_clarra_login_page() throws InterruptedException {
		
		Assert.assertTrue(loginPage.emailLoginPageIsDisplayed());

	}

	@When("Input User name and password")
	public void input_user_name_and_password() {
		loginPage.inputEmaildata();
		loginPage.inputPassword();
	}

	@When("Click on Signin button")
	public void click_on_signin_button() throws InterruptedException {
		loginPage.clicksubmitButton();
	}


}
