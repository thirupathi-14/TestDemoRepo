package StepDefinitions;

import org.testng.Assert;

import PageObjects.LoginPage;
import PageObjects.MattersPage;
import Utilities.TestContext;
import io.cucumber.java.en.Given;

public class MattersSteps {

	TestContext testContext;
	MattersPage mattersPage;

	public MattersSteps(TestContext context) {
		testContext = context;
		mattersPage = testContext.getPageObjectManager().getMattersPage();
	}
	
	@Given("Click On Matters Menu")
	public void clickOnMattersMenu() throws InterruptedException {
		mattersPage.clickOnMattersMenu();

	}
	
	@Given("Click On Matters Events Menu")
	public void clickOnMattersEventsMenu() throws InterruptedException {
		mattersPage.clickOnmattersEventsMenu();

	}
	
	@Given("Click On Matters Details")
	public void clickOnMattersDetails() throws InterruptedException {
		mattersPage.clickOnMattersDetails();

	}
	
	@Given("Verify Matters Event Description")
	public void verifyMattersEventDescriptn() throws InterruptedException {
		String actual=mattersPage.verifyMattersDescription();
		if(actual.equalsIgnoreCase("Demo description"))
		{
			Assert.assertEquals(actual, "Demo description");
		}

	}
	
	@Given("Verify Matters Event Notes")
	public void verifyMattersEventNotes() throws InterruptedException {
		String actual=mattersPage.verifyMattersNotes();
		if(actual.equalsIgnoreCase("Welcome"))
		{
			Assert.assertEquals(actual, "Welcome");
		}

	}


}
