package StepDefinitions;

import org.testng.Assert;

import PageObjects.TimeKeepingPage;
import Utilities.TestContext;
import io.cucumber.java.en.Then;

public class TimeKeeping {

	TestContext testContext;
	TimeKeepingPage timeKeepingPage;

	public TimeKeeping(TestContext context) {
		testContext = context;
		timeKeepingPage = testContext.getPageObjectManager().getTimeKeepingPage();
	}

	@Then("Click on TimeKeeping button")
	public void click_on_TimeKeeping_button() {
		timeKeepingPage.clickTimeKeepingSideNav();

	}

	@Then("Create TimeKeeping NewSlip button")
	public void Create_TimeKeeping_NewSlip_button() throws InterruptedException {
		timeKeepingPage.clickNewTimeSlip();
		Thread.sleep(6000);

	}

	@Then("Fill Matter,Type,Project,Description,Notes")
	public void fill_matter_type_project_description() {
		timeKeepingPage.selectMatter();
		timeKeepingPage.inputDescription();
		timeKeepingPage.inputNotes();
		timeKeepingPage.selectType();
		timeKeepingPage.selectProject();
		timeKeepingPage.clickStartButton();
		timeKeepingPage.clickMinimizeButton();
	}

	@Then("Verify login successful")
	public void verify_login_successful() throws InterruptedException {
		Thread.sleep(10000);
		Assert.assertTrue(timeKeepingPage.isTimeKeepDisplayed());
		System.out.println("Login Successfull");
		

	}
}
