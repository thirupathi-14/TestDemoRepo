package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DashboardPage {
	 private final WebDriver webDriver;
	 public static long TIMEOUT=5000L;
    public DashboardPage(WebDriver webDriver) {
    	 this.webDriver = webDriver;
    	PageFactory.initElements(webDriver, this);
    }
    
    @FindBy(xpath = "//p[contains(text(),'Dashboard')]")
    private WebElement dashboardMenu;
    
    @FindBy(xpath = "//span[@mattooltip='Add New']")
    private WebElement addNew;
    
    @FindBy(xpath = "//div[@role='menu']/div/button[2]")
    private WebElement dashboradNewEvent;
    
    public void clickOnDashbordMenu() throws InterruptedException
    {
    	dashboardMenu.click();
    	Thread.sleep(4000);
    }
    
    public void clickOnaddNew() throws InterruptedException
    {
    	addNew.click();
    	Thread.sleep(4000);
    }
    
    public void clickOnDashboradNewEvent() throws InterruptedException
    {
    	dashboradNewEvent.click();
    	Thread.sleep(4000);
    }
  

}
