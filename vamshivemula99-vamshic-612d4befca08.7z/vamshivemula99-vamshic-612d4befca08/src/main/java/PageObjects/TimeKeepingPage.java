package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import Utilities.Wait;

public class TimeKeepingPage {
	 private final WebDriver webDriver;
	 public static long TIMEOUT=5000L;
    public TimeKeepingPage(WebDriver webDriver) {
    	 this.webDriver = webDriver;
    	PageFactory.initElements(webDriver, this);
    }

    @FindBy(xpath = "//ul[@class='Desktop-Menu ng-star-inserted']//img[@class='sidenav-timekeeping']")
    private WebElement timeKeepingButton;

    @FindBy(xpath = "//button[contains(@routerlink,'timekeeping')]")
    private WebElement newTimeSlipButton;
    
    @FindBy(id = "searchInput")
    private WebElement matterSearchInput;

    @FindBy(xpath = "//mat-option[1]")
    private WebElement mattOption1;
    
  
    @FindBy(xpath = "//label[contains(text(),'Type')]/following-sibling::select")
    private WebElement typeSelect;

    
    @FindBy(xpath = "//label[contains(text(),'Project')]/following-sibling::select")
    private WebElement projectSelect;
    
    
    @FindBy(xpath = "//label[contains(text(),'Description')]/following-sibling::textarea")
    private WebElement descriptionTextArea;
    
    @FindBy(xpath = "//label[contains(text(),'Note')]/following-sibling::textarea")
    private WebElement noteTextArea;

    @FindBy(xpath = "//button[text()='Start']")
    private WebElement startButton;
  
    @FindBy(xpath = "//button[text()='Minimize']")
    private WebElement minimizeButton;
   
    public void clickTimeKeepingSideNav() {
        timeKeepingButton.click();
      }
    
    public void clickNewTimeSlip() {
    	Wait.untilElementIsVisible(webDriver, newTimeSlipButton, TIMEOUT);
        newTimeSlipButton.click();
      }

    public void selectMatter() {
        matterSearchInput.isEnabled();
        matterSearchInput.clear();
        matterSearchInput.sendKeys("In");
        Wait.untilElementIsVisible(webDriver, mattOption1, TIMEOUT);
        mattOption1.click();
    }
   
   
    
    public void selectType() {
    	//Thread.sleep(5000);
    	Wait.untilElementIsVisible(webDriver, typeSelect, TIMEOUT);
        Select typeDropdown = new Select(typeSelect);
        typeDropdown.selectByValue("3308");
         
      }
    
    public void selectProject() {
        Select projectDropdown = new Select(projectSelect);
        projectDropdown.selectByValue("572");    
      }
    
    public void inputDescription() {
        descriptionTextArea.sendKeys("Demo description");    
      }
    
    public void inputNotes() {
        noteTextArea.sendKeys("Demo Notes");    
      }
    
    public boolean isTimeKeepDisplayed() {
        return timeKeepingButton.isDisplayed();   
      }
    public void clickStartButton() {
    	startButton.click();
        
      }
    
    public void clickMinimizeButton() {
        minimizeButton.click();
      }

}
