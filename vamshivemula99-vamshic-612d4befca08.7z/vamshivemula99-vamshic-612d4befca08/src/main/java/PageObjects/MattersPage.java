package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MattersPage {
	 private final WebDriver webDriver;
	 public static long TIMEOUT=5000L;
    public MattersPage(WebDriver webDriver) {
    	 this.webDriver = webDriver;
    	PageFactory.initElements(webDriver, this);
    }
    

    @FindBy(xpath = "//p[contains(text(),'Matters')]")
    private WebElement mattersMenu;
    
    @FindBy(xpath = "//button[contains(@class,'Events')]")
    private WebElement mattersEventsMenu;
    
    @FindBy(xpath = " //button[@mattooltip='Details']")
    private WebElement mattersDetails;
    
    @FindBy(xpath = "//label[contains(text(),'Demo description')]")
    private WebElement mattersDemodescription;
 
    @FindBy(xpath = "//label[contains(text(),'Welcome')]")
    private WebElement mattersNotes;
    
  public void clickOnMattersMenu() throws InterruptedException
  {
	  mattersMenu.click();
	  Thread.sleep(4000);
  }
  
  public void clickOnmattersEventsMenu() throws InterruptedException
  {
	  mattersEventsMenu.click();
	  Thread.sleep(4000);
  }
  
  public void clickOnMattersDetails() throws InterruptedException
  {
	  mattersDetails.click();
	  Thread.sleep(4000);
  }
  
  public String verifyMattersDescription()
  {
	  return mattersDemodescription.getText();
  }
  
  public String verifyMattersNotes()
  {
	  return mattersNotes.getText();
  }
    
    

}
