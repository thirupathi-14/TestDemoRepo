package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Utilities.Wait;

public class LoginPage {
	 private final WebDriver webDriver;
    public LoginPage(WebDriver webDriver) {
    	 this.webDriver = webDriver;
    	PageFactory.initElements(webDriver, this);
    }

   

    @FindBy(id = "email")
    private WebElement emailField;
    
    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(id = "next")
    private WebElement submitButton;
    
   
  
    

    public void inputEmaildata() {
        emailField.isEnabled();
        emailField.clear();
        emailField.sendKeys("vamshi1@clarra.com");
    }
    public void inputPassword() {
    	passwordField.isEnabled();
    	passwordField.clear();
    	passwordField.sendKeys("Clarra@123");
    }
    
    public void clicksubmitButton() throws InterruptedException {
    	submitButton.click();
    	Thread.sleep(4000);
    }
    

    public boolean emailLoginPageIsDisplayed() {
        emailField.isDisplayed();
        submitButton.isDisplayed();
        return true;
    }

    public void fillEmailData(String email) {
        emailField.isEnabled();
        emailField.clear();
        emailField.sendKeys(email);
    }
}
