package Managers;

import org.openqa.selenium.WebDriver;

import PageObjects.HomePage;
import PageObjects.LoginPage;
import PageObjects.MattersPage;
import PageObjects.TimeKeepingPage;
import PageObjects.DashboardPage;
import PageObjects.EventsPage;

public class PageObjectManager {

    private final WebDriver webDriver;
    private LoginPage loginPage;
    private TimeKeepingPage timeKeepingPage;
    private HomePage homePage;
    private EventsPage eventsPage;
private MattersPage mattersPage;
private DashboardPage dashboardPage;
    public PageObjectManager(WebDriver webDriver) {
        this.webDriver = webDriver;
    }

    //Short Hand If...Else
    public HomePage getHomePage() {
        return (homePage == null) ? homePage = new HomePage(webDriver) : homePage;
    }
    
    public EventsPage getEventsPage() {
        return (eventsPage == null) ? eventsPage = new EventsPage(webDriver) : eventsPage;
    }
    public MattersPage getMattersPage() {
        return (mattersPage == null) ? mattersPage = new MattersPage(webDriver) : mattersPage;
    }
    public DashboardPage getDashboardPage() {
        return (dashboardPage == null) ? dashboardPage = new DashboardPage(webDriver) : dashboardPage;
    }
    public TimeKeepingPage getTimeKeepingPage() {
        return (timeKeepingPage == null) ? timeKeepingPage = new TimeKeepingPage(webDriver) : timeKeepingPage;
    }
    //General If...Else
    public LoginPage getLoginPage() {

        if (loginPage == null) {
            loginPage = new LoginPage(webDriver);
        }
        return loginPage;
    }

}
