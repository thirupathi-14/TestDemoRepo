package Enums;

public enum DriverType {
    FIREFOX,
    CHROME,
    EDGE,
    SAFARI
}
