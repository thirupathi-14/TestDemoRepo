package Enums;

public enum Context {
    EXPECTED_DATA;
}
