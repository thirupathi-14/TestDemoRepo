package Enums;

public enum EnvironmentType {
    LOCAL,
    REMOTE
}
