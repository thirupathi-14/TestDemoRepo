package clarra.hooks;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import clarra.clarra.utilities.TestSettings;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import net.thucydides.core.annotations.Managed;

public class Hooks {

	// @Managed(uniqueSession = true)
	@Managed(uniqueSession = true, driver = "Chrome")
	WebDriver driver;
	public static TestSettings testSettings;
	public static Properties credentials;
	String root = System.getProperty("user.dir");
	public static Properties CONFIG = null;

	public Hooks() {
		System.out.println("--------------------INITIALIZE HOOKS----------------------"); 
		testSettings = TestSettings.getInstance();
		credentials = testSettings.getConfigProp();
	}

	@Before
	public void BeforeScenario() throws IOException {
		System.out.println("--------------------BEFORE SCENARIO----------------------");
		
//		CONFIG = new Properties();
//		FileInputStream fs = new FileInputStream(root + "/configuration/CONFIG.properties");
//		CONFIG.load(fs);
//		System.setProperty("webdriver.chrome.driver", (root + CONFIG.getProperty("Chrome_Driver_Path")));
//		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
//		DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
//		ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
//		ieCapabilities.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, true);
//		ieCapabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//		ieCapabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
//		ieCapabilities.setCapability(CapabilityType.PAGE_LOAD_STRATEGY, true);
//		ieCapabilities.setCapability(CapabilityType.PROXY, true);
//		ieCapabilities.setCapability(CapabilityType.SUPPORTS_ALERTS, true);
//		ieCapabilities.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
//		ieCapabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, true);
//		ieCapabilities.setCapability(CapabilityType.UNHANDLED_PROMPT_BEHAVIOUR, true);
//		ieCapabilities.setCapability(CapabilityType.SUPPORTS_NETWORK_CONNECTION, true);
//		ieCapabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);

		
		//driver = new InternetExplorerDriver(ieCapabilities);
		//driver.manage().window().maximize();
		/*
		 * System.out.println(driver.manage().window().getSize()); //Create object of
		 * Dimensions class // Dimension d = new Dimension(1936, 1066); Dimension d =
		 * new Dimension(1900, 1050); //Resize the current window to the given dimension
		 * driver.manage().window().setSize(d);
		 * System.out.println(driver.manage().window().getSize());
		 */
       

	}

	@After
	public void AfterScenario() {
		System.out.println("--------------------AFTER SCENARIO----------------------");
		driver.quit();
	}

}
