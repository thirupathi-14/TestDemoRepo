package clarra.pages.pageObjects;


import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.PageFactory;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class DashboardPage extends PageObject {
	
    
    @FindBy(xpath = "//p[contains(text(),'Dashboard')]")
    private WebElement dashboardMenu;
    
    @FindBy(xpath = "//span[@mattooltip='Add New']")
    private WebElement addNew;
    
    @FindBy(xpath = "//div[@role='menu']/div/button[2]")
    private WebElement dashboradNewEvent;
    
    public void clickOnDashbordMenu() throws InterruptedException
    {
    	Thread.sleep(4000);
    	dashboardMenu.click();
    	Thread.sleep(4000);
    }
    
    public void clickOnaddNew() throws InterruptedException
    {
    	addNew.click();
    	Thread.sleep(4000);
    }
    
    public void clickOnDashboradNewEvent() throws InterruptedException
    {
    	dashboradNewEvent.click();
    	Thread.sleep(4000);
    }
  

}
