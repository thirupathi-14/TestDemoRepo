package clarra.pages.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import clarra.clarra.utilities.SeleniumFunctions;

import junit.framework.Assert;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class TimeKeepingPage extends PageObject {
	
	SeleniumFunctions seleniumFunctions;
	
	
	 @FindBy(xpath = "//ul[@class='Desktop-Menu ng-star-inserted']//img[@class='sidenav-timekeeping']")
	    private WebElement timeKeepingTab;
	
    @FindBy(xpath = "//ul[@class='Desktop-Menu ng-star-inserted']//img[@class='sidenav-timekeeping']")
    private WebElement timeKeepingButton;

    @FindBy(xpath = "//button[contains(text(),'New Timeslip')]")
    private WebElement newTimeSlipButton;
 
    @FindBy(id = "searchInput")
    private WebElement matterSearchInput;

    @FindBy(xpath = "//mat-option[1]")
    private WebElement mattOption1;
    
  
    @FindBy(xpath = "//label[contains(text(),'Type')]/following-sibling::select")
    private WebElement typeSelect;
    @FindBy(xpath = "//label[contains(text(),' Timekeeper* ')]/following-sibling::select")
    private WebElement timeKeeper;
    
  //

    
    @FindBy(xpath = "//label[contains(text(),'Project')]/following-sibling::select")
    private WebElement projectSelect;
    
    
    @FindBy(xpath = "//label[contains(text(),'Description')]/following-sibling::textarea")
    private WebElement descriptionTextArea;
    
    @FindBy(xpath = "//label[contains(text(),'Note')]/following-sibling::textarea")
    private WebElement noteTextArea;

    @FindBy(xpath = "//button[text()='Start']")
    private WebElement startButton;
  
    @FindBy(xpath = "//button[contains(text(),'Minimize')]")
    private WebElement minimizeButton;
    
    @FindBy(xpath = "//button[contains(text(),'New Timeslip')]")
    private WebElement createNewTimeslip;
  
    
    @FindBy(xpath = "//label[contains(text(),'Type')]/following-sibling::select")
    private WebElement selectTimekeeping;
    
    @FindBy(xpath = "(//input[@placeholder='Search'])[2]")
    private WebElement searchTextBox;
    
    @FindBy(xpath = "//input[@placeholder='Search']/following::span[@class='contacts-search']")
    private WebElement searchButton;
    
    @FindBy(xpath = " //mat-icon[contains(text(),'schedule')]")
    private WebElement mattersTimeKeeping;
    
    @FindBy(xpath = " //mat-icon[contains(text(),'edit')]")
    private WebElement editTimeKeeping;
    
    @FindBy(xpath = "//button[contains(text(),'Pause')]")
    private WebElement pauseButton;
    
    @FindBy(xpath = "//input[@placeholder='Duration']")
    private WebElement durationTxtBox;
    
    @FindBy(xpath = "//input[@placeholder='Matter']")
    private WebElement matterTxtBox;
    
    @FindBy(xpath = "//button[contains(text(),'+ New Timeslip')]")
    private WebElement dashboardTimeSlip;
    
    @FindBy(xpath = "//button[contains(text(),'Minimize')]/following::button[contains(text(),'Save')]")
    private WebElement saveButton;
    
    @FindBy(id = "Duplicate")
    private WebElement saveAndDuplicateButton;
    
    @FindBy(xpath = "//button[contains(text(),'Save and + New')]")
    private WebElement saveAndNewButton;
    
    public void clickOnSaveAndNewButton() throws InterruptedException {
    	Thread.sleep(5000);
    	//seleniumFunctions.ScrollIntoView(saveButton);
    	saveAndNewButton.click();
    	Thread.sleep(2000);
      }
    
    
    public void clickOnSaveAndDuplicateButton() throws InterruptedException {
    	Thread.sleep(5000);
    	//seleniumFunctions.ScrollIntoView(saveButton);
    	saveAndDuplicateButton.click();
    	Thread.sleep(2000);
      }
    

    public void clickOnSaveButton() throws InterruptedException {
    	Thread.sleep(5000);
    	//seleniumFunctions.ScrollIntoView(saveButton);
    	saveButton.click();
    	Thread.sleep(2000);
      }
    
  
    public void clickOnDashboardTimeSlip() throws InterruptedException {
    	Thread.sleep(2000);
    	dashboardTimeSlip.click();
    	Thread.sleep(2000);
      }
    
    
    public void enterTimeKeepingMatter(String matter) throws InterruptedException {
    	Thread.sleep(4000);
    	matterTxtBox.clear();
    	matterTxtBox.sendKeys(matter);
    	Thread.sleep(4000);
    	getDriver().findElement(By.xpath("//span[contains(text(),' In ray with new matter ')]")).click();
    	
    	Thread.sleep(2000);
      }
  
    
    public void enterDuration(String duration) throws InterruptedException {
    	Thread.sleep(4000);
    	durationTxtBox.clear();
    	durationTxtBox.sendKeys(duration);
    	Thread.sleep(4000);
      }
    
    public void clickOnPauseButton() throws InterruptedException {
    	Thread.sleep(4000);
    	pauseButton.click();
    	Thread.sleep(4000);
      }
    
    public void clickOnEditTimeKeeping() throws InterruptedException {
    	Thread.sleep(4000);
    	editTimeKeeping.click();
    	Thread.sleep(4000);
      }
    
 
    public void clickMattersTimeKeeping() {
    	mattersTimeKeeping.click();
      }
  

    public void enterDescriptionAndSearch(String desc) throws InterruptedException {
    	Thread.sleep(10000);
    	searchTextBox.sendKeys(desc);
    	Thread.sleep(3000);
    	searchButton.click();
    	Thread.sleep(2000);
      }
  
    
  
  
   
    public void clickTimeKeepingSideNav() {
        timeKeepingButton.click();
      }
    
    public void clickTimeKeepingTab() {
    	seleniumFunctions.waitForElementToBePresent(timeKeepingTab);
    	timeKeepingTab.click();
      }
    
    
    
    public void clickNewTimeSlip() throws InterruptedException {
    	Thread.sleep(4000);
    	seleniumFunctions.waitForElementToBePresent(newTimeSlipButton);
        newTimeSlipButton.click();
      }

    public void selectMatter() {
        matterSearchInput.isEnabled();
        matterSearchInput.clear();
        matterSearchInput.sendKeys("In");
        
    	seleniumFunctions.waitForElementToBePresent(mattOption1);
        mattOption1.click();
    }
   
   public void selectTimeKeeper()
   {
	   Select timekeeper=new Select(timeKeeper);
	   timekeeper.selectByIndex(1);
	   
   }
    
    public void selectType() {
    	//Thread.sleep(5000);
    	
    	seleniumFunctions.waitForElementToBePresent(typeSelect);
        Select typeDropdown = new Select(typeSelect);
        typeDropdown.selectByValue("3308");
         
      }
    
    public void selectProject() {
        Select projectDropdown = new Select(projectSelect);
        projectDropdown.selectByValue("572");    
      }
    
    public void inputDescription(String Description) {
        descriptionTextArea.sendKeys(Description);    
      }
    
    public void inputNotes() {
        noteTextArea.sendKeys("Demo Notes");    
      }
    
    public boolean isTimeKeepDisplayed() {
        return timeKeepingButton.isDisplayed();   
      }
    public void clickStartButton() {
    	startButton.click();
        
      }
    
    public void clickMinimizeButton() throws InterruptedException {
    	seleniumFunctions.ScrollIntoView(minimizeButton);
        minimizeButton.click();
        Thread.sleep(10000);
      }
    
    public void verifyNewTimeSlipCreation(String desc)
    {
    	Assert.assertEquals(desc, getDriver().findElement(By.xpath("//span[contains(text(),' "+desc+" ')]")).getText());
    }

}
