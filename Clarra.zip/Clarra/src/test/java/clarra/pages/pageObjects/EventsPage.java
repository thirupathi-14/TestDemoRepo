package clarra.pages.pageObjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import org.apache.velocity.runtime.directive.Parse;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.Select;

import clarra.clarra.utilities.SeleniumFunctions;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.PageObjects;



public class EventsPage extends PageObject {
	
	String root=System.getProperty("user.dir");
    
    SeleniumFunctions seleniumFunctions;

    @FindBy(xpath = "//ul[@class='Desktop-Menu ng-star-inserted']//img[@class='sidenav-events']")
    private WebElement eventsButton;

    @FindBy(xpath = "//button[contains(text(),'New Event')]")
    private WebElement newEventsButton;
    
    @FindBy(id = "searchInput")
    private WebElement matterSearchInput;

    @FindBy(xpath = "//mat-option[1]")
    private WebElement mattOption1;
    
  
    @FindBy(xpath = "//label[contains(text(),'Event Code')]/following-sibling::select")
    private WebElement EventcodeSelect;
    
    @FindBy(xpath="//input[contains(@class,'mat-date')]")
    private WebElement inputdate;
    
    
    @FindBy(xpath="//input[contains(@class,'time-text-box')]")
    private WebElement Inputhour;
    
    @FindBy(name="minutes")
    private WebElement Inputmin;
    
    
    @FindBy(xpath = "//label[contains(text(),' Duration')]/following-sibling::select")
    private WebElement DurationHours;
    
    @FindBy(xpath = " //mat-datepicker-toggle[@class='mat-datepicker-toggle']")
    private WebElement datePickerIcon;
    
 
    
    
    
    

    
    @FindBy(xpath = "//label[contains(text(),'Project')]/following-sibling::select")
    private WebElement projectSelect;
    
    
    @FindBy(xpath = "//label[contains(text(),'Description')]/following-sibling::textarea")
    private WebElement descriptionTextArea;
    
    @FindBy(xpath = "//label[contains(text(),'Note')]/following-sibling::textarea")
    private WebElement noteTextArea;

    @FindBy(xpath = "//button[text()='Start']")
    private WebElement startButton;
  
    @FindBy(xpath = "//button[text()='Minimize']")
    private WebElement minimizeButton;
    
    @FindBy(xpath = " //mat-select[@panelclass='MatSelectPanelForForms']")
    private WebElement assignedToListBox;
    
    @FindBy(xpath = "//span[contains(text(),' vamshi v (ABC) ')]")
    private WebElement assignedToListValue;
    
    @FindBy(xpath = "(//mat-select[@panelclass='MatSelectPanelForForms'])[2]")
    private WebElement followersListBox;
    
    @FindBy(xpath = "//span[contains(text(),' vamshi v (ABC) ')]")
    private WebElement followersListValue;
    
    @FindBy(xpath = "(//button[contains(text(),'Save')])[2]")
    private WebElement saveButton;
    
    @FindBy(xpath = " //img[@class='sidenav-events']/following::p[contains(text(),'Events')]")
    private WebElement enventsMenu;
    
    @FindBy(xpath = "//textarea[@placeholder='Notes']")
    private WebElement noteText;
    
    @FindBy(xpath = "//select")
    private WebElement evenCodeListBox;
    @FindBy(xpath = "//select/option[contains(text(),'CU-998')]")
    private WebElement evenCodeValue;
    
    @FindBy(xpath = "//span[@class='date-menu-arrow-down']")
    private WebElement dateMenuDownArrow;
    
    @FindBy(xpath = "//button[contains(text(),'Apply')]")
    private WebElement applyButton;
    
    @FindBy(xpath = " //button/span[contains(text(),'Apply')]")
    private WebElement fillterApplyButton;
    
 
    
    @FindBy(xpath = "//button[contains(text(),'Audit Trail')]")
    private WebElement auditTrail;
    
    @FindBy(xpath = "//button[contains(text(),'Edit ')]")
    private WebElement editButton;
    
    @FindBy(xpath = "//td[contains(text(),'Event Creation')]")
    private WebElement editCreation;
    
    @FindBy(xpath = "//div[contains(text(),'Recuring event Description')]")
    private WebElement evenDescriptionLink;
    
    @FindBy(xpath = "//select[@formcontrolname='daysBeforeStart']")
    private WebElement remindersDropDown;
    
    @FindBy(xpath = "//option[contains(text(),'1 day')]")
    private WebElement oneDay;
    
    @FindBy(xpath = "(//select[@autocomplete=\"off\"])[6]")
    private WebElement statusDropDown;
    
    
    @FindBy(xpath = "//option[contains(text(),'Off Calendar')]")
    private WebElement selectOffCalendar;
    
    
    @FindBy(xpath = "//option[contains(text(),'In Progress')]")
    private WebElement selectInProgress;
    
    @FindBy(xpath = "//span[contains(text(),'filter_list ')]")
    private WebElement filtters;
    
    @FindBy(xpath = "//mat-select[@formcontrolname='statuses']")
    private WebElement filtterStatusDropDown;
    
    @FindBy(xpath = "//label[contains(text(),' Recurring Event * ')]/following::select")
    private WebElement recurringEventsDropDown;
    
    @FindBy(id = "rangeTypeNoEnd")
    private WebElement noEndDate;
    
    @FindBy(xpath = "(//mat-datepicker-toggle[@class='mat-datepicker-toggle'])[3]")
    private WebElement selectEndDate;
    
    
    public void selectEndDateWithOneMonth() throws InterruptedException {
   	 //Thread.sleep(2000);
   	 seleniumFunctions.waitFor(selectEndDate);
   	selectEndDate.click();
   	 Thread.sleep(2000);
   	 LocalDate currentdate = LocalDate.now();
     System.out.println("Current date: "+currentdate);
     //Getting the current day
     int currentDay = currentdate.getDayOfMonth();
     String day=Integer.toString(currentDay);
     getDriver().findElement(By.xpath("//button[@aria-label='Next month']")).click();
     Thread.sleep(2000);
   	getDriver().findElement(By.xpath("//td/div[contains(text(),'"+day+"')]")).click();
    Thread.sleep(2000);
   	 
     }
    
    public void clickOnNoEndDate() throws InterruptedException {
    	 //Thread.sleep(2000);
    	 seleniumFunctions.waitFor(noEndDate);
    	 noEndDate.click();
    	 Thread.sleep(2000);
      }
  
  
    
    public void selectRecurringEventStatusDropDown(String daily) throws InterruptedException {
    	 Thread.sleep(2000);
    	 recurringEventsDropDown.click();
    	 Thread.sleep(2000);
    	 getDriver().findElement(By.xpath("//option[contains(text(),'"+daily+"')]")).click();
      }
  
    public void clickOnFiltterStatusDropDown() throws InterruptedException {
     	 Thread.sleep(2000);
     	filtterStatusDropDown.click();
     	 Thread.sleep(2000);
       }
    
    
    public void clickOnFillterApplyButton() throws InterruptedException {
     	 Thread.sleep(2000);
     	
		seleniumFunctions.ScrollIntoView(fillterApplyButton);
		Thread.sleep(2000);
     	fillterApplyButton.click();
     	 Thread.sleep(4000);
       }
  
    
    public void clickOnFiltters() throws InterruptedException {
      	 Thread.sleep(2000);
      	filtters.click();
      	 Thread.sleep(2000);
        }
   
    public void selectOffCalendarCheckBox() throws InterruptedException, AWTException
    {
    	List<WebElement> li=getDriver().findElements(By.xpath("//mat-pseudo-checkbox"));
    	int i=li.size();
    	for(int j=0;j<i;j++)
    	{
    		if(li.get(j).isSelected()==true)
    		{
    			li.get(j).click();
    		}
    	}
    	Thread.sleep(4000);
    	getDriver().findElement(By.xpath("(//span[contains(text(),'Off Calendar ')]/preceding::mat-pseudo-checkbox)[2]")).click();
    	 Robot robot = new Robot();
   	  robot.keyPress(KeyEvent.VK_ESCAPE);
    }
    
    public void clickOnStatusDropDown() throws InterruptedException {
   	 Thread.sleep(2000);
   	statusDropDown.click();
   	 Thread.sleep(2000);
     }
    public void selectOffCalendar() throws InterruptedException {
   	 Thread.sleep(2000);
   	selectOffCalendar.click();
   	 Thread.sleep(2000);
     }
    public void selectInProgress() throws InterruptedException {
   	 Thread.sleep(2000);
   	selectInProgress.click();
   	 Thread.sleep(2000);
     }
    		
    		
    		
    
    public void clickOnRemindersDropDown() throws InterruptedException {
    	 Thread.sleep(2000);
    	 seleniumFunctions.ScrollIntoView(remindersDropDown);
    	 remindersDropDown.click();
    	 Thread.sleep(2000);
      }
    public void selectOneDay() throws InterruptedException {
    	 Thread.sleep(2000);
    	 oneDay.click();
    	 Thread.sleep(2000);
      }
  
    public String getDescription() throws IOException
    {
    	 FileReader reader=new FileReader(root+"/testdata/TestData.properties");  
         
    	    Properties p=new Properties();  
    	    p.load(reader);  
    	     String desc=p.getProperty("Description"); 
    	   // System.out.println();  
    	     return desc;
    }
    
    public void clickOnEvenDescriptionLink() throws InterruptedException, IOException {
     	 Thread.sleep(4000);
     	//evenDescriptionLink.click();
     	String desc=getDescription();
     	 Thread.sleep(4000);
     	getDriver().findElement(By.xpath("//div[contains(text(),'"+desc+"')]")).click();
     	 Thread.sleep(4000);
       }
    
    public void clickOnEvenLink(String value) throws InterruptedException {
    	 Thread.sleep(4000);
    	 getDriver().findElement(By.xpath("//div[contains(text(),'"+value+"')]")).click();
    	 Thread.sleep(4000);
      }
    
  
    
    public void clickOnEditButton() throws InterruptedException {
      	 Thread.sleep(4000);
      	editButton.click();
      	 Thread.sleep(4000);
      	
           
        }
    
    public void clickOnAuditTrailButton() throws InterruptedException
    {
		/*
		 * Actions actions = new Actions(getDriver());
		 * actions.moveToElement(auditTrail).build().perform();
		 * 
		 */
    	seleniumFunctions.ScrollIntoView(auditTrail);
		//actions.perform();
		 Thread.sleep(4000);
		 auditTrail.click();
    	Thread.sleep(4000);
    }
  
    public String verifyEditCreation()
    {
    	String edit=editCreation.getText();
       return edit;
    }
    
  
    public void clickOnApplyButton() throws InterruptedException {
   	      Thread.sleep(4000);
        	applyButton.click();
   	     Thread.sleep(4000);
     }
  
    
  
    
    
    public void selectEventCode() throws InterruptedException {
    	 Thread.sleep(4000);
    	 evenCodeListBox.click();
    	 Thread.sleep(4000);
    	 evenCodeValue.click();
         
      }
    
    public void selectEventCode(String value) throws InterruptedException {
   	 Thread.sleep(4000);
   	 evenCodeListBox.click();
   	 Thread.sleep(4000);
   	getDriver().findElement(By.xpath("//select/option[contains(text(),'"+value+"')]")).click();
   	
        
     }
    
  
    
    public void enterNotes() throws InterruptedException
    {
    	noteText.sendKeys("Welcome");
    	Thread.sleep(4000);
    }
    
    public void enterNotes(String value) throws InterruptedException
    {
    	noteText.sendKeys(value);
    	Thread.sleep(4000);
    }
    
    
    public void clickOnEventsMenu()
    {
    	enventsMenu.click();
    }
  
    
    public void clickOnSaveButton() throws InterruptedException
    {
		/*
		 * Actions actions = new Actions(getDriver());
		 * actions.moveToElement(saveButton).build().perform();
		 */
		seleniumFunctions.ScrollIntoView(saveButton);
		
		//actions.perform();
		 Thread.sleep(4000);
		 seleniumFunctions.click_On_Element(saveButton);
    	//saveButton.click();
    	Thread.sleep(4000);
    }
  
    
    
    public void selectfollowersList() throws InterruptedException, AWTException
    {
    	followersListBox.click();
    	Thread.sleep(4000);
 	   seleniumFunctions.waitForElementToBePresent(followersListBox);
 	  followersListValue.click();
 	 Thread.sleep(4000);
 	 Robot robot = new Robot();
	  robot.keyPress(KeyEvent.VK_ESCAPE);
// 	 Actions action = new Actions(getDriver());
//	   action.sendKeys(Keys.ESCAPE).build().perform();
    }
    
    public void selectfollowersList(String follower) throws InterruptedException, AWTException
    {
    	followersListBox.click();
    	Thread.sleep(4000);
 	 
 	//  seleniumFunctions.waitForElementToBePresent(followersListBox);
 	  getDriver().findElement(By.xpath("//span[contains(text(),'"+follower+"')]")).click();
 	 
 	 Thread.sleep(4000);
 	 Robot robot = new Robot();
	  robot.keyPress(KeyEvent.VK_ESCAPE);
    }
    
  
   public void selectAssignedToList() throws InterruptedException, AWTException
   {
	   assignedToListBox.click();
	
	   //seleniumFunctions.waitForElementToBePresent(assignedToListValue);
	   Thread.sleep(4000);
	   assignedToListValue.click();
	   Thread.sleep(4000);
	   Robot robot = new Robot();
		  robot.keyPress(KeyEvent.VK_ESCAPE);
		/*
		 * Actions action = new Actions(getDriver());
		 * action.sendKeys(Keys.ESCAPE).build().perform();
		 */
   }
   
   public void selectAssignedToList(String assigne) throws InterruptedException, AWTException
   {
	   assignedToListBox.click();
	   Thread.sleep(4000);
	   //seleniumFunctions.waitForElementToBePresent(assignedToListValue);
	   getDriver().findElement(By.xpath("//span[contains(text(),'"+assigne+"')]")).click();
	  
	   Thread.sleep(4000);
	   Robot robot = new Robot();
	  robot.keyPress(KeyEvent.VK_ESCAPE);
		/*
		 * Actions action = new Actions(getDriver());
		 * action.sendKeys(Keys.ESCAPE).build().perform();
		 */
   }
   
    public void clickeventsSideNav() {
    	eventsButton.click();
      }
    
    public void clickNeweventsSlip() {
    	
    	seleniumFunctions.waitForElementToBePresent(newEventsButton);
    	newEventsButton.click();
      }

    public void selectMatter() {
        matterSearchInput.isEnabled();
        matterSearchInput.clear();
        matterSearchInput.sendKeys("In");
      
    	seleniumFunctions.waitForElementToBePresent(mattOption1);
        mattOption1.click();
    }
    
    public String tomorrowDate()
    {
    	 LocalDate currentdate = LocalDate.now();
         System.out.println("Current date: "+currentdate);
         //Getting the current day
         int currentDay = currentdate.getDayOfMonth();
         System.out.println("Current day: "+currentDay);
         int i=currentDay+2;
         String day=Integer.toString(i);
    	return day;
    }
    
    public String twoDaysDate()
    {
    	 LocalDate currentdate = LocalDate.now();
         System.out.println("Current date: "+currentdate);
         //Getting the current day
         int currentDay = currentdate.getDayOfMonth();
         System.out.println("Current day: "+currentDay);
         int i=currentDay+2;
         String day=Integer.toString(i);
    	return day;
    }
    
    public String futureDate(int j)
    {
    	 LocalDate currentdate = LocalDate.now();
         System.out.println("Current date: "+currentdate);
         //Getting the current day
         int currentDay = currentdate.getDayOfMonth();
         System.out.println("Current day: "+currentDay);
         int i=currentDay+j;
         String day=Integer.toString(i);
    	return day;
    }
    public void enter2DaysDate() throws InterruptedException
    {
    	Thread.sleep(4000);
    	
    	seleniumFunctions.waitForElementToBePresent(datePickerIcon);
    	datePickerIcon.click();
    	String day=twoDaysDate();
    	System.out.print("day values is :"+ day);
    	getDriver().findElement(By.xpath("//td/div[contains(text(),'"+day+"')]")).click();
    		//inputdate.sendKeys();
    }
    public void enterDate() throws InterruptedException
    {
    	Thread.sleep(4000);
    
      	seleniumFunctions.waitForElementToBePresent(datePickerIcon);
    	datePickerIcon.click();
    	String day=tomorrowDate();
    	System.out.print("day values is :"+ day);
    	getDriver().findElement(By.xpath("//td/div[contains(text(),'"+day+"')]")).click();
    		//inputdate.sendKeys();
    }
    
    public void selectDate() throws InterruptedException
    {
    	Thread.sleep(5000);
    	dateMenuDownArrow.click();
    	getDriver().findElement(By.xpath("(//mat-datepicker-toggle[@class='mat-datepicker-toggle'])[5]")).click();
    	//Wait.untilElementIsVisible(webDriver, datePickerIcon, TIMEOUT);
    	//datePickerIcon.click();
    	Thread.sleep(4000);
    	String day=tomorrowDate();
    	System.out.print("day values is :"+ day);
    	getDriver().findElement(By.xpath("(//td/div[contains(text(),'"+day+"')])[2]")).click();
    		//inputdate.sendKeys();
    }
    
    public void selec2daystDate() throws InterruptedException
    {
    	Thread.sleep(4000);
    	dateMenuDownArrow.click();
    	getDriver().findElement(By.xpath("(//mat-datepicker-toggle[@class='mat-datepicker-toggle'])[5]")).click();
    	//Wait.untilElementIsVisible(webDriver, datePickerIcon, TIMEOUT);
    	//datePickerIcon.click();
    	Thread.sleep(4000);
    	String day=twoDaysDate();
    	System.out.print("day values is :"+ day);
    	getDriver().findElement(By.xpath("(//td/div[contains(text(),'"+day+"')])[2]")).click();
    		//inputdate.sendKeys();
    }
    
    public String verifyNonReccuringEvent()
    {
    	String event=getDriver().findElement(By.xpath("//div[contains(text(),'In ray with new matter, (100002), Demo description')]")).getText();
   return event;
    }
    
    public String verifyNonReccuringEventOffCalendar()
    {
    	String event=getDriver().findElement(By.xpath("//div[contains(text(),'In ray with new matter, (100002), Off Calendar ')]")).getText();
   return event;
    }
    
    public String verifyUpdatedEventcode()
    {
    	String event=getDriver().findElement(By.xpath("//label[contains(text(),'ARB')]")).getText();
		return event;
  
    }
    
    public String verifyUpdatedDescription()
    {
    	String event=getDriver().findElement(By.xpath("//label[contains(text(),'Welcome')]")).getText();
		return event;
  
    }
    
    
  
    
    
    public void enterHourAndMin()
    {
    	Inputhour.clear();
    	Inputhour.sendKeys("11");
    	Inputmin.clear();
    	Inputmin.sendKeys("10");
    }
   
    public void enterDuration()
    {
    	Select typeDropdown = new Select(DurationHours);
         typeDropdown.selectByValue("1");
    	
    }
   
    
    public void selectType() {
    	//Thread.sleep(5000);
    	//Wait.untilElementIsVisible(webDriver, typeSelect, TIMEOUT);
        //Select typeDropdown = new Select(typeSelect);
       // typeDropdown.selectByValue("3308");
         
      }
    
    public void selectProject() {
        Select projectDropdown = new Select(projectSelect);
        projectDropdown.selectByValue("572");    
      }
    
    public void inputDescription() {
        descriptionTextArea.sendKeys("Demo description");    
      }
    
   public void setData(String desc) throws IOException
   {
	   Properties props = new Properties();
	   props.clear();
	      //Populating the properties file
	      props.put("Description", desc);
	     
	      //Instantiating the FileInputStream for output file
	      String path = root+"/testdata/TestData.properties";
	      FileOutputStream outputStrem = new FileOutputStream(path);
	     
	      //Storing the properties file
	      props.store(outputStrem, "This is a sample properties file");
	      System.out.println("Properties file created......");
	      outputStrem.close();
	      
   }
   
   public int randomNumber()
   {
	   Random random=new Random();
	   int i=random.nextInt(10000);
	   return i;
   }
    
    public void inputDescription(String value) throws IOException {
    	
    	int number=randomNumber();
    	String values=Integer.toString(number);
    	String description=values+value;
    	
    	setData(description);
    	 descriptionTextArea.clear();
        descriptionTextArea.sendKeys(description);    
      }
    
    public void inputNotes() {
        noteTextArea.sendKeys("Demo Notes");    
      }
    
    /*public boolean isTimeKeepDisplayed() {
        return timeKeepingButton.isDisplayed();   
      }*/
    public void clickStartButton() {
    	startButton.click();
        
      }
    
    public void clickMinimizeButton() {
        minimizeButton.click();
      }


	

}
