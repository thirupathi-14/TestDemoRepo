package clarra.pages.pageObjects;


import org.openqa.selenium.WebElement;

import clarra.clarra.utilities.CommonFunctions;
import clarra.clarra.utilities.SeleniumFunctions;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class MattersPage extends PageObject{
	
	SeleniumFunctions seleniumFunctions;
	CommonFunctions commonfunctions;

    @FindBy(xpath = "//div/img[@class='sidenav-matters']")
    private WebElement mattersMenu;
    
    @FindBy(xpath = "//button[contains(@class,'Events')]")
    private WebElement mattersEventsMenu;
    
    @FindBy(xpath = " //button[@mattooltip='Details']")
    private WebElement mattersDetails;
    
    @FindBy(xpath = "//label[contains(text(),'Demo description')]")
    private WebElement mattersDemodescription;
 
    @FindBy(xpath = "//label[contains(text(),'Welcome')]")
    private WebElement mattersNotes;
    
  public void clickOnMattersMenu() throws InterruptedException
  {
	 // seleniumFunctions.wait(4);
	 // commonfunctions.wait();
	 // commonfunctions.clickOn(mattersMenu);
	  //seleniumFunctions.clickOn(mattersMenu);
	  mattersMenu.click();
	 
  }
  
  public void clickOnmattersEventsMenu() throws InterruptedException
	{/*
		 * seleniumFunctions.waitFor(mattersEventsMenu);
		 * seleniumFunctions.clickOn(mattersEventsMenu);
		 */
	  mattersEventsMenu.click();
	 
  }
  
  public void clickOnMattersDetails() throws InterruptedException
  {
		/*
		 * seleniumFunctions.waitFor(mattersDetails);
		 * seleniumFunctions.clickOn(mattersDetails);
		 */
	  Thread.sleep(10000);
	  mattersDetails.click();
	  
  }
  
  public String verifyMattersDescription()
  {
	  return mattersDemodescription.getText();
  }
  
  public String verifyMattersNotes()
  {
	  return mattersNotes.getText();
  }
    
    

}
