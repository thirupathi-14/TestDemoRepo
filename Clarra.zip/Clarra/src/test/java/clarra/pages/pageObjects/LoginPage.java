package clarra.pages.pageObjects;


import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;



public class LoginPage extends PageObject {
	

   

    @FindBy(id = "email")
    private WebElement emailField;
    
    @FindBy(id = "password")
    private WebElement passwordField;

    @FindBy(id = "next")
    private WebElement submitButton;
    
    @FindBy(xpath = "//ul[@class='Desktop-Menu ng-star-inserted']//img[@class='sidenav-timekeeping']")
    private WebElement timeKeepingButton;
  
    

    public void inputEmaildata() {
        emailField.isEnabled();
        emailField.clear();
        emailField.sendKeys("vamshi1@clarra.com");
    }
    public void inputPassword() {
    	passwordField.isEnabled();
    	passwordField.clear();
    	passwordField.sendKeys("Clarra@123");
    }
    
    public void clicksubmitButton() throws InterruptedException {
    	submitButton.click();
    	Thread.sleep(4000);
    }
    

    public boolean emailLoginPageIsDisplayed() {
        emailField.isDisplayed();
        submitButton.isDisplayed();
        return true;
    }

    public void fillEmailData(String email) {
        emailField.isEnabled();
        emailField.clear();
        emailField.sendKeys(email);
    }
    
    public boolean verifyLoginSuccessfully()
    {
    	timeKeepingButton.isDisplayed();
    	return true;
    }
    
}
