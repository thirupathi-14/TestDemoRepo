package clarra.pages.serenitySteps;

import org.junit.runner.RunWith;


import clarra.clarra.utilities.CommonFunctions;
import clarra.pages.pageObjects.MattersPage;
import junit.framework.Assert;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.junit.runners.SerenityRunner;

@RunWith(SerenityRunner.class)
public class MattersSteps  extends PageObject {
	CommonFunctions common_functions;
	MattersPage mattersPage;

	public void clickOnMattersMenu() throws InterruptedException {
		mattersPage.clickOnMattersMenu();

	}
	
	
	public void clickOnMattersEventsMenu() throws InterruptedException {
		mattersPage.clickOnmattersEventsMenu();

	}
	
	
	public void clickOnMattersDetails() throws InterruptedException {
		mattersPage.clickOnMattersDetails();

	}
	
	
	public void verifyMattersEventDescriptn() throws InterruptedException {
		String actual=mattersPage.verifyMattersDescription();
		if(actual.equalsIgnoreCase("Demo description"))
		{
			Assert.assertEquals(actual, "Demo description");
		}

	}
	
	
	public void verifyMattersEventNotes() throws InterruptedException {
		String actual=mattersPage.verifyMattersNotes();
		if(actual.equalsIgnoreCase("Welcome"))
		{
			Assert.assertEquals(actual, "Welcome");
		}

	}

}
