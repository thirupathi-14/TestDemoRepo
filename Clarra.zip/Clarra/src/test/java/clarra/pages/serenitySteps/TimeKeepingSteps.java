package clarra.pages.serenitySteps;

import org.junit.runner.RunWith;

import clarra.clarra.utilities.CommonFunctions;
import clarra.clarra.utilities.SeleniumFunctions;
import clarra.pages.pageObjects.TimeKeepingPage;

import junit.framework.Assert;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Step;

@RunWith(SerenityRunner.class)
public class TimeKeepingSteps extends PageObject {
	CommonFunctions common_functions;
	TimeKeepingPage timeKeepingPage;
	
	SeleniumFunctions seleniumFunctions;
	@Step
	public void clickOnTimeKeepingTab()
	{
		
		timeKeepingPage.clickTimeKeepingTab();
	}
	

	@Step
	public void clickOnStartButton()
	{
		
		timeKeepingPage.clickStartButton();
	}
	
	@Step
	public void clickOnNewTimeSlip() throws InterruptedException
	{
		
		timeKeepingPage.clickNewTimeSlip();
	}
	@Step
	public void selectTimeKeepers()
	{
		
		timeKeepingPage.selectTimeKeeper();
	}
	
	@Step
	public void selectType()
	{
		
		timeKeepingPage.selectType();
	}
	@Step
	public void selectProject()
	{
		
		timeKeepingPage.selectProject();
	}
	
	@Step
	public void enterDescription(String Description)
	{
		
		timeKeepingPage.inputDescription(Description);
	}
	@Step
	public void enterNotes()
	{
		
		timeKeepingPage.inputNotes();
	}
	
	@Step
	public void clickOnMinizeButton() throws InterruptedException
	{
		
		timeKeepingPage.clickMinimizeButton();
	}
	
	@Step
	public void enterDescriptionAndSearch1(String desc) throws InterruptedException
	{
		timeKeepingPage.enterDescriptionAndSearch(desc);
	}
	
	@Step
	public void verifyNewTimeslip(String desc)
	{
		timeKeepingPage.verifyNewTimeSlipCreation(desc);
	}
	@Step
	public void clickOnMattersTimeKeeping()
	{
		timeKeepingPage.clickMattersTimeKeeping();
	}
	
	@Step
	public void clickOnEditTimeKeeping() throws InterruptedException
	{
		timeKeepingPage.clickOnEditTimeKeeping();
	}
	
	@Step
	public void  clickOnPauseButton() throws InterruptedException
	{
		timeKeepingPage.clickOnPauseButton();
	}
	
	@Step
	public void  inputDuration(String duration) throws InterruptedException
	{
		timeKeepingPage.enterDuration(duration);
	}
	
	@Step
	public void  inputTimekeepingMatter(String matter) throws InterruptedException
	{
		timeKeepingPage.enterTimeKeepingMatter(matter);
	}
	@Step
	public void  clickOnDashboardTimeSlip() throws InterruptedException
	{
		timeKeepingPage.clickOnDashboardTimeSlip();
	}
	
	@Step
	public void  clickOnSaveButton() throws InterruptedException
	{
		timeKeepingPage.clickOnSaveButton();
	}
	
	@Step
	public void  clickOnSaveAndDuplicateButton() throws InterruptedException
	{
		timeKeepingPage.clickOnSaveAndDuplicateButton();
	}
	
	@Step
	public void  clickOnSaveAndNewButton() throws InterruptedException
	{
		timeKeepingPage.clickOnSaveAndNewButton();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
