package clarra.pages.serenitySteps;

import java.awt.AWTException;
import java.io.IOException;

import org.junit.runner.RunWith;

import clarra.clarra.utilities.CommonFunctions;
import clarra.pages.pageObjects.EventsPage;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
@RunWith(SerenityRunner.class)
public class EventsSteps extends PageObject{
	CommonFunctions common_functions;
	
	EventsPage eventsPage;
	@Step
	public void clickOnNewEventButton() {
		
		eventsPage.clickNeweventsSlip();
	}
	
	@Step
	public void clickOnEventMenu() {
		
		eventsPage.clickOnEventsMenu();
	}
	@Step
	public void clickOnApplyButton() throws InterruptedException {
		
		eventsPage.clickOnApplyButton();
	}
	
	@Step
	public void clickOnFillterApplyButton() throws InterruptedException {
		
		eventsPage.clickOnFillterApplyButton();
	}
	
	
	@Step
	public void selectDate() throws InterruptedException {
		
		eventsPage.selectDate();
	}
	
	@Step
	public void selec2daystDate() throws InterruptedException {
		
		eventsPage.selec2daystDate();
	}
	
	
	
	@Step
	public void fillterAndSelectOffCalendar() throws InterruptedException, AWTException {
		eventsPage.clickOnFiltters();
		eventsPage.clickOnFiltterStatusDropDown();
		eventsPage.selectOffCalendarCheckBox();
	}
	
	
	
	@Step
	public void verifyNonRecurringEvent()
	{
		String event=eventsPage.verifyNonReccuringEvent();
		if(event.equalsIgnoreCase("In ray with new matter, (100002), Demo description (vv3p)"))
		   {
			//Assert.assertEquals(event,"In ray with new matter, (100002), Demo description (vv3p)");
		   }
	}
	
	@Step
	public void verifyNonReccuringEventOffCalendar()
	{
		String event=eventsPage.verifyNonReccuringEventOffCalendar();
		if(event.equalsIgnoreCase("In ray with new matter, (100002), Off Calendar (vv3p)"))
		   {
		//	 Assert.assertEquals(event,"In ray with new matter, (100002), Off Calendar (vv3p)");
		   }
	}
	
	
	
	@Step
	public void enterDateAndTime() throws InterruptedException {
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
	}
	
	@Step
	public void selectDuration() {
		
		eventsPage.enterDuration();
		
	}
	
	@Step
	public void selectMatter() {
		
		eventsPage.selectMatter();
		
	}
	
	@Step
	public void selectAssigne() throws InterruptedException, AWTException {
		
		eventsPage.selectAssignedToList();
		
	}
	
	@Step
	public void selectFollowers() throws InterruptedException, AWTException {
		
		eventsPage.selectfollowersList();
		
	}
	
	@Step
	public void enterDescrption() throws InterruptedException {
		
		eventsPage.inputDescription();
		eventsPage.enterNotes();
		
	}
	
	@Step
	public void clickOnSaveButton() throws InterruptedException {
		eventsPage.clickOnSaveButton();
		
	}
	
	@Step
	public void clickOnEvenDescriptionLink() throws InterruptedException, IOException {
		eventsPage.clickOnEvenDescriptionLink();
		
	}
	
	@Step
	public void clickOnEvenInprogressLink() throws InterruptedException {
		Thread.sleep(4000);
		eventsPage.clickOnEvenLink("InProgress");
		Thread.sleep(4000);
		
	}
	
	@Step
	public void clickOnEvenWelcomeLink() throws InterruptedException {
		Thread.sleep(4000);
		eventsPage.clickOnEvenLink("Welcome");
		Thread.sleep(4000);
		
	}
	@Step
	public void clickOnEvenOffCalendarLink() throws InterruptedException {
		Thread.sleep(4000);
		eventsPage.clickOnEvenLink("Off Calendar");
		Thread.sleep(4000);
		
	}
	
	
	
	@Step
	public void clickOnEditButton() throws InterruptedException {
		eventsPage.clickOnEditButton();
		
	}
	
	@Step
	public void clickOnAditTrialButton() throws InterruptedException {
		eventsPage.clickOnAuditTrailButton();
		
	}
	
	@Step
	public void verifyEventCreation() throws InterruptedException {
		String event=eventsPage.verifyEditCreation();
		if(event.equalsIgnoreCase("Event Creation"))
		   {
		//	 Assert.assertEquals(event,"Event Creation");
		   }
		
	}
	
	@Step
	public void verifyEventUpdatedValues() throws InterruptedException {
		String eventCode=eventsPage.verifyUpdatedEventcode();
		if(eventCode.equalsIgnoreCase("ARB"))
		   {
		//	 Assert.assertEquals(eventCode,"ARB");
		   }
		
		String description=eventsPage.verifyUpdatedDescription();
		if(description.equalsIgnoreCase("Welcome"))
		   {
		//	 Assert.assertEquals(description,"Welcome");
		   }
		
	}
	
	
	
	@Step
	public void fillNecessaryFiledsAndClickOnSave(String desc) throws InterruptedException, AWTException, IOException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.inputDescription(desc);
		eventsPage.enterNotes();
		eventsPage.clickOnSaveButton();
	}
	
	@Step
	public void fillNecessaryFiledsAndClickOnSaveWithOndeyReminder1(String desc) throws InterruptedException, AWTException, IOException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.clickOnRemindersDropDown();
		eventsPage.selectOneDay();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.inputDescription(desc);
		eventsPage.enterNotes();
		eventsPage.clickOnSaveButton();
	}
	
	@Step
	public void fillNecessaryFiledsAndClickOnSaveWithInProgress1() throws InterruptedException, AWTException, IOException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.clickOnStatusDropDown();
		eventsPage.selectInProgress();
		eventsPage.inputDescription("InProgress");
		eventsPage.enterNotes();
		eventsPage.clickOnSaveButton();
	}
	
	@Step
	public void fillNecessaryFiledsAndClickOnSaveWithOffCalender1() throws InterruptedException, AWTException, IOException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.clickOnStatusDropDown();
		eventsPage.selectOffCalendar();
		eventsPage.inputDescription("Off Calendar");
		eventsPage.enterNotes();
		eventsPage.clickOnSaveButton();
	}
	
	
	@Step
	public void fillNecessaryFiledsAndClickOnSaveWithUpdate1(String desc) throws InterruptedException, AWTException, IOException {
		
		eventsPage.selectEventCode("ARB");
		eventsPage.enter2DaysDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList(" vamshi v (ABC) ");
		eventsPage.selectfollowersList(" vamshi3 v (vv3p) ");
		eventsPage.inputDescription(desc);
		eventsPage.enterNotes("Welcome");
		eventsPage.clickOnSaveButton();
	}
	
	
	@Step
	public void fillNecessaryFiledsForReccurringEventAndClickOnSave(String daily) throws InterruptedException, AWTException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectRecurringEventStatusDropDown(daily);
		eventsPage.clickOnNoEndDate();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.inputDescription();
		eventsPage.enterNotes();
		
	}
	
	@Step
	public void fillNecessaryFiledsForReccurringEventWithEndDate(String daily) throws InterruptedException, AWTException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectRecurringEventStatusDropDown(daily);
		eventsPage.selectEndDateWithOneMonth();
		eventsPage.clickOnRemindersDropDown();
		eventsPage.selectOneDay();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.inputDescription();
		eventsPage.enterNotes();
		
	}
	
	
	
	@Step
	public void fillNecessaryFiledsForReccurringEventWithNoEndDateAndOneDayReminder(String daily) throws InterruptedException, AWTException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectRecurringEventStatusDropDown(daily);
		eventsPage.clickOnNoEndDate();
		eventsPage.clickOnRemindersDropDown();
		eventsPage.selectOneDay();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.inputDescription();
		eventsPage.enterNotes();
		
	}
	
	@Step
	public void fillNecessaryFiledsForReccurringEventWithOneMonthAndEvenInProgress(String daily) throws InterruptedException, AWTException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectRecurringEventStatusDropDown(daily);
		eventsPage.selectEndDateWithOneMonth();
		eventsPage.clickOnRemindersDropDown();
		eventsPage.selectOneDay();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.clickOnStatusDropDown();
		eventsPage.selectInProgress();
		eventsPage.inputDescription();
		eventsPage.enterNotes();
		
	}
	

	@Step
	public void fillNecessaryFiledsForReccurringEventWithOneMonthAndEvenOffCalender(String daily) throws InterruptedException, AWTException {
		
		eventsPage.selectEventCode();
		eventsPage.enterDate();
		eventsPage.enterHourAndMin();
		eventsPage.enterDuration();
		eventsPage.selectRecurringEventStatusDropDown(daily);
		eventsPage.selectEndDateWithOneMonth();
		eventsPage.clickOnRemindersDropDown();
		eventsPage.selectOneDay();
		eventsPage.selectMatter();
		eventsPage.selectAssignedToList();
		eventsPage.selectfollowersList();
		eventsPage.clickOnStatusDropDown();
		eventsPage.selectOffCalendar();
		eventsPage.inputDescription();
		eventsPage.enterNotes();
		
	}
	


}
