package clarra.pages.serenitySteps;

import org.junit.runner.RunWith;

import clarra.clarra.utilities.CommonFunctions;
import clarra.pages.pageObjects.DashboardPage;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;

@RunWith(SerenityRunner.class)
public class DashboardSteps extends PageObject {
	CommonFunctions common_functions;
	

	DashboardPage dashboardPage;
	
	@Step
	public void clickOnDashboardMenu() throws InterruptedException {
		
		dashboardPage.clickOnDashbordMenu();
	}
	
	@Step
	public void clickOnaddNew() throws InterruptedException {
		
		dashboardPage.clickOnaddNew();
	}
	
	@Step
	public void clickOnDashboardNewEvent() throws InterruptedException {
		
		dashboardPage.clickOnDashboradNewEvent();
	}

	
}
