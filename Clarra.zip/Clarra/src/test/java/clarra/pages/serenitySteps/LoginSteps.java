package clarra.pages.serenitySteps;

import java.io.IOException;

import org.junit.runner.RunWith;

import clarra.clarra.utilities.CommonFunctions;
import clarra.pages.pageObjects.LoginPage;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;

@RunWith(SerenityRunner.class)
public class LoginSteps extends PageObject {
	CommonFunctions common_functions;
	
	
	LoginPage loginPage;
	
	@Step
	public void launch_clarra_login_page() throws InterruptedException, IOException {
		
		//Assert.assertTrue(loginPage.emailLoginPageIsDisplayed());
		common_functions.launch_clarra_portal_app();

	}

	@Step
	public void input_user_name_and_password() throws InterruptedException {
		loginPage.inputEmaildata();
		loginPage.inputPassword();
		loginPage.clicksubmitButton();
	}

	@Step
	public void click_on_signin_button() throws InterruptedException {
		loginPage.clicksubmitButton();
	}
	@Step
	public void verify_login_successful() throws InterruptedException {
		Thread.sleep(10000);
		loginPage.verifyLoginSuccessfully();
		
		

	}

}
