package clarra.pages.stepDefinitions;

import clarra.pages.serenitySteps.LoginSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class LoginStepDefinition {
	@Steps
	LoginSteps loginSteps;

	@Given("^clarra portal is launched$")
	public void launch_eplacement_portal() throws Throwable {
		loginSteps.launch_clarra_login_page();
	}

	@When("^User provides login details and click on login button$")
	public void login_to_clarra() throws Throwable {
		loginSteps.input_user_name_and_password();
	}	

	@Then("Verify login successful")
	public void verify_login_successful() throws InterruptedException {
		loginSteps.verify_login_successful();

	}

}
