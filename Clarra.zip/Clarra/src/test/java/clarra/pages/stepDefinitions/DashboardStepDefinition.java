package clarra.pages.stepDefinitions;

import clarra.pages.pageObjects.DashboardPage;
import clarra.pages.serenitySteps.DashboardSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class DashboardStepDefinition {
	@Steps
	DashboardSteps dashboardsteps;
	
	@Given("^Click On Dashboard Menu$")
	public void click_OnDashboardMenu() throws InterruptedException {
		
		dashboardsteps.clickOnDashboardMenu();
	}
	
	@Then("^Click On Add New$")
	public void click_OnaddNew() throws InterruptedException {
		
		dashboardsteps.clickOnaddNew();
	}
	
	@Then("^Click On Dashboard New Event$")
	public void click_OnDashboardNewEvent() throws InterruptedException {
		
		dashboardsteps.clickOnDashboardNewEvent();
	}


}
