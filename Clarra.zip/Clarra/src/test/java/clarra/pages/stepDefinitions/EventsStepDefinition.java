package clarra.pages.stepDefinitions;




import java.awt.AWTException;
import java.io.IOException;

import clarra.pages.serenitySteps.EventsSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class EventsStepDefinition {
	@Steps
	EventsSteps eventsSteps;
	
	@Given("^Click On New Event Button$")
	public void click_OnNewEventButton() {
		
		eventsSteps.clickOnNewEventButton();
	}
	
	@When("^Click On Events Menu$")
	public void click_OnEventMenu() {
		
		eventsSteps.clickOnEventMenu();
	}
	@When("Click On Apply Button")
	public void click_OnApplyButton() throws InterruptedException {
		
		eventsSteps.clickOnApplyButton();
	}
	
	@When("Click On Fillter Apply Button")
	public void click_OnFillterApplyButton() throws InterruptedException {
		
		eventsSteps.clickOnFillterApplyButton();
	}
	
	
	@When("Select Date")
	public void select_Date() throws InterruptedException {
		
		eventsSteps.selectDate();
	}
	
	@When("Select 2daystDate")
	public void selec2_daystDate() throws InterruptedException {
		
		eventsSteps.selec2daystDate();
	}
	
	
	
	@When("Filter and select OffCalendar")
	public void fillterAnd_SelectOffCalendar() throws InterruptedException, AWTException {
		eventsSteps.fillterAndSelectOffCalendar();
		
	}
	
	
	
	@When("Verify NonRecurring Event Created.")
	public void verify_NonRecurringEvent()
	{
		/*
		 * String event=eventsSteps.verifyNonRecurringEvent(); if(event.
		 * equalsIgnoreCase("In ray with new matter, (100002), Demo description (vv3p)"
		 * )) { // Assert.assertEquals(
		 * event,"In ray with new matter, (100002), Demo description (vv3p)"); }
		 */
	}
	
	@When("Verify NonRecurring Event OffCalendar Created.")
	public void verifyNonReccuring_EventOffCalendar()
	{
		/*
		 * String event=eventsSteps.verifyNonReccuringEventOffCalendar(); if(event.
		 * equalsIgnoreCase("In ray with new matter, (100002), Off Calendar (vv3p)")) {
		 * .event. Assert.assertEquals(
		 * event,"In ray with new matter, (100002), Off Calendar (vv3p)"); }
		 */
	}
	
	
	
	@When("Enter Date And Time")
	public void enterDate_AndTime() throws InterruptedException {
		eventsSteps.enterDateAndTime();
		
	}
	
	@When("Select Duration")
	public void select_Duration() {
		
		eventsSteps.selectDuration();
		
	}
	
	@When("Select Matter")
	public void select_Matter() {
		
		eventsSteps.selectMatter();
		
	}
	
	@When("Select AssignedTo")
	public void select_Assigne() throws InterruptedException, AWTException {
		
		eventsSteps.selectAssigne();
		
	}
	
	@When("Select Followres")
	public void select_Followers() throws InterruptedException, AWTException {
		
		eventsSteps.selectFollowers();
		
	}
	
	@When("Enter Description")
	public void enter_Descrption() throws InterruptedException {
		
		eventsSteps.enterDescrption();
		
		
	}
	
	@Then("^Click On Save Button$")
	public void clickOn_SaveButton() throws InterruptedException {
		eventsSteps.clickOnSaveButton();
		
	}
	
	@When("Click On Event Link")
	public void clickOn_EvenDescriptionLink() throws InterruptedException, IOException {
		eventsSteps.clickOnEvenDescriptionLink();
		
	}
	
	@When("Click On EventInprogress Link")
	public void clickOn_EvenInprogressLink() throws InterruptedException {
		Thread.sleep(4000);
		eventsSteps.clickOnEvenInprogressLink();
		Thread.sleep(4000);
		
	}
	
	@When("Click On welcome Link")
	public void clickOn_EvenWelcomeLink() throws InterruptedException {
		Thread.sleep(4000);
		eventsSteps.clickOnEvenWelcomeLink();
		Thread.sleep(4000);
		
	}
	@When("Click On EventOffCalendar Link")
	public void clickOn_EvenOffCalendarLink() throws InterruptedException {
		Thread.sleep(4000);
		eventsSteps.clickOnEvenOffCalendarLink();
		Thread.sleep(4000);
		
	}
	
	
	
	@When("Click On Edit Button")
	public void clickOn_EditButton() throws InterruptedException {
		eventsSteps.clickOnEditButton();
		
	}
	
	@When("Click On AditTrial Button")
	public void clickOn_AditTrialButton() throws InterruptedException {
		eventsSteps.clickOnAditTrialButton();
		
	}
	
	@When("Verify Event Creation")
	public void verify_EventCreation() throws InterruptedException {
		/*
		 * String event=eventsSteps.verifyEventCreation();
		 * if(event.equalsIgnoreCase("Event Creation")) { //
		 * Assert.assertEquals(event,"Event Creation"); }
		 */
		
	}
	
	@When("Verify Event Updated Values")
	public void verify_EventUpdatedValues() throws InterruptedException {
		/*
		 * String eventCode=eventsSteps.verifyUpdatedEventcode();
		 * if(eventCode.equalsIgnoreCase("ARB")) { //
		 * Assert.assertEquals(eventCode,"ARB"); }
		 * 
		 * String description=eventsSteps.verifyUpdatedDescription();
		 * if(description.equalsIgnoreCase("Welcome")) { //
		 * Assert.assertEquals(description,"Welcome"); }
		 */
		
	}
	
	
	
	@When("^Fill Necessary filed and Click on Save \"([^\"]*)\"$")
	public void fill_NecessaryFiledsAndClickOnSave(String desc) throws InterruptedException, AWTException, IOException {
		
		eventsSteps.fillNecessaryFiledsAndClickOnSave(desc);
	}
	
	@Then("^Fill Necessary filed and Click on Save with Dashboard OneDay reminder \"([^\"]*)\"$")
	public void fill_NecessaryFiledsAndClickOnSaveWithOndeyReminder(String desc) throws InterruptedException, AWTException, IOException {
		
		eventsSteps.fillNecessaryFiledsAndClickOnSaveWithOndeyReminder1(desc);
	}
	
	@Then("^Fill Necessary filed and Click on Save With InProgress$")
	public void fill_NecessaryFiledsAndClickOnSaveWithInProgress() throws InterruptedException, AWTException, IOException {
		
		eventsSteps.fillNecessaryFiledsAndClickOnSaveWithInProgress1();
	}
	
	@Then("^Fill Necessary filed and Click on Save With OffCalender$")
	public void fill_NecessaryFiledsAndClickOnSaveWithOffCalender() throws InterruptedException, AWTException, IOException {
		
		eventsSteps.fillNecessaryFiledsAndClickOnSaveWithOffCalender1();
	}
	
	
	@Then("^Fill Necessary filed and Click on Save with Update \"([^\"]*)\"$")
	public void fill_NecessaryFiledsAndClickOnSaveWithUpdate(String desc) throws InterruptedException, AWTException, IOException {
		
		eventsSteps.fillNecessaryFiledsAndClickOnSaveWithUpdate1(desc);
	}
	
	@Then("^Fill Necessary filed for ReccurringEvent with \"([^\"]*)\" and Click on Save$")
	public void fill_NecessaryFiledsReccurringEventAndClickOnSave(String daily) throws InterruptedException, AWTException {
		
		eventsSteps.fillNecessaryFiledsForReccurringEventAndClickOnSave(daily);
	}
	
	@Then("^Fill Necessary filed for ReccurringEvent with endDate \"([^\"]*)\"$")
	public void fill_NecessaryFiledsReccurringEventWithEndDate(String daily) throws InterruptedException, AWTException {
		
		eventsSteps.fillNecessaryFiledsForReccurringEventWithEndDate(daily);
	}
	

	@Then("^Fill Necessary filed for ReccurringEvent with noEndDate oneDay Reminder \"([^\"]*)\"$")
	public void fill_NecessaryFiledsReccurringEventWithNoEndDateOneDayReminder(String daily) throws InterruptedException, AWTException {
		
		eventsSteps.fillNecessaryFiledsForReccurringEventWithNoEndDateAndOneDayReminder(daily);
	}

	@Then("^Fill Necessary filed for ReccurringEvent with EndDate And Inprogress \"([^\"]*)\"$")
	public void fill_NecessaryFiledsForReccurringEventWithOneMonthAndEvenInProgress(String daily) throws InterruptedException, AWTException {
		
		eventsSteps.fillNecessaryFiledsForReccurringEventWithOneMonthAndEvenInProgress(daily);
	}
	
	@Then("^Fill Necessary filed for ReccurringEvent with EndDate And OffCalender \"([^\"]*)\"$")
	public void fill_NecessaryFiledsForReccurringEventWithOneMonthAndEvenOffCalender(String daily) throws InterruptedException, AWTException {
		
		eventsSteps.fillNecessaryFiledsForReccurringEventWithOneMonthAndEvenOffCalender(daily);
	}

	
	
	
	

}
