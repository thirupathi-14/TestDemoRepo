package clarra.pages.stepDefinitions;

import clarra.pages.serenitySteps.TimeKeepingSteps;
import cucumber.api.java.en.Then;
import junit.framework.Assert;
import net.thucydides.core.annotations.Steps;

public class TimeKeepingStepDefination {
	@Steps
	TimeKeepingSteps timeKeepingSteps;
	
	@Then("^Click On TimeKeeping Tab$")
	public void clickOnTimekeepingTab()
	{
		timeKeepingSteps.clickOnTimeKeepingTab();
	}
	
	@Then("^Click On New Time slip$")
	public void clickOnTimeSlip() throws InterruptedException
	{
		timeKeepingSteps.clickOnNewTimeSlip();
	}
	
	@Then("^Click on Start button$")
	public void clickOnStartButton()
	{
		timeKeepingSteps.clickOnStartButton();
	}
	
	@Then("^Select timekeeper$")
	public void selectTieKeeper()
	{
		timeKeepingSteps.selectTimeKeepers();
	}
	
	@Then("^Choose Type$")
	public void selectType()
	{
		timeKeepingSteps.selectType();
	}
	
	@Then("^Select Project$")
	public void clickOnSelectProject()
	{
		timeKeepingSteps.selectProject();
	}
	
	@Then("^Enter TimeKeeper Description \"([^\"]*)\"$")
	public void enterDescripton(String Description)
	{
		timeKeepingSteps.enterDescription(Description);
	}
	
	@Then("^Enter Time Keeper Note$")
	public void enterNotes()
	{
		timeKeepingSteps.enterNotes();
	}
	
	@Then("^Click Minimize Button$")
	public void clickOnMinimizeButton() throws InterruptedException
	{
		timeKeepingSteps.clickOnMinizeButton();
	}
	
	@Then("^Verify Time slip is appraring in the Unsaved TimeSlips Section in Green color \"([^\"]*)\"$")
	public void verifyTimeSlipIsApprearing(String desc)
	{
		timeKeepingSteps.verifyNewTimeslip(desc);
	}
	
	@Then("^Enter TimeSlip And Search1 \"([^\"]*)\"$")
	public void clickOnMinimizeButton(String desc) throws InterruptedException
	{
		timeKeepingSteps.enterDescriptionAndSearch1(desc);
	}
	
	@Then("^Click Matters TimeKeeping$")
	public void clickOnEventTimeKeeping() throws InterruptedException
	{
		timeKeepingSteps.clickOnMattersTimeKeeping();
	}
	
	@Then("^Click Edit TimeKeeping$")
	public void clickOnEditTimeKeeping() throws InterruptedException
	{
		timeKeepingSteps.clickOnEditTimeKeeping();
	}
	
	@Then("^Click Pause Button$")
	public void clickOnPauseButton() throws InterruptedException
	{
		timeKeepingSteps.clickOnPauseButton();
	}
	
	@Then("^Enter Duration \"([^\"]*)\"$")
	public void InputDuration(String duration) throws InterruptedException
	{
		timeKeepingSteps.inputDuration(duration);
	}
	
	@Then("^Enter TimeKeeping Matter \"([^\"]*)\"$")
	public void inputTimeKeepingMatter(String matter) throws InterruptedException
	{
		timeKeepingSteps.inputTimekeepingMatter(matter);
	}
	@Then("^Click Dashboard TimeSlip Button$")
	public void clickOnDashboardTimeSlip() throws InterruptedException
	{
		timeKeepingSteps.clickOnDashboardTimeSlip();
	}
	
	@Then("^Click TimeSlip Save Button$")
	public void clickOnTimeSlipSaveButton() throws InterruptedException
	{
		timeKeepingSteps.clickOnSaveButton();
	}
	
	@Then("^Click TimeSlip Save And Duplicate Button$")
	public void clickOnSaveAndDuplicateButton() throws InterruptedException
	{
		timeKeepingSteps.clickOnSaveAndDuplicateButton();
	}
	
	@Then("^Click TimeSlip Save And New Button$")
	public void clickOnSaveAndNewButton() throws InterruptedException
	{
		timeKeepingSteps.clickOnSaveAndNewButton();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
