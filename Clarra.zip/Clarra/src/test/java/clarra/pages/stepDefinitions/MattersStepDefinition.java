package clarra.pages.stepDefinitions;



import clarra.pages.serenitySteps.MattersSteps;
import cucumber.api.java.en.Then;

import net.thucydides.core.annotations.Steps;

public class MattersStepDefinition {
	@Steps
	MattersSteps mattersSteps;
	
	@Then("^Click On Matters Menu$")
	public void clickOnMattersMenu() throws InterruptedException {
		mattersSteps.clickOnMattersMenu();

	}
	
	@Then("^Click On Matters Events Menu$")
	public void clickOnMattersEventsMenu() throws InterruptedException {
		mattersSteps.clickOnMattersEventsMenu();

	}
	
	@Then("^Click On Matters Details$")
	public void clickOnMattersDetails() throws InterruptedException {
		mattersSteps.clickOnMattersDetails();

	}
	
	@Then("^Verify Matters Event Description$")
	public void verifyMattersEventDescriptn() throws InterruptedException {
		
		mattersSteps.verifyMattersEventDescriptn();
	}
	
	@Then("^Verify Matters Event Notes$")
	public void verifyMattersEventNotes() throws InterruptedException {
		
		mattersSteps.verifyMattersEventNotes();
	}


}
