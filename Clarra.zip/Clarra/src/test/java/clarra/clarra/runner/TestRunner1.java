package clarra.clarra.runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

/**
 * Created 
 */

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = {"./resources/features"},
tags = { " @TimeKeeping_14 " },

	plugin = { "json:target/cucumber-parallel/1.json",
				"html:target/cucumber-parallel/1.html", "pretty" }, 
		glue = {"clarra.pages.stepDefinitions","clarra.hooks" }, 
		monochrome = true, 
		strict = true)

public class TestRunner1 {
 
}
