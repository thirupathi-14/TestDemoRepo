package clarra.clarra.utilities;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;

import net.serenitybdd.core.pages.PageObject;

//* Static Selenium Functions ***************************************/
public class SeleniumFunctions extends PageObject {
	CommonFunctions common_functions;
	static WebDriver dr;
	
	
	//Method for clicking on element
	public static void click_On_Element(WebElement element) {		

		if (isElementPresent(element)) {
			element.click();
		}
	}
	
	// Enter value into text field 
	public static void enterValueintotextfield(WebElement element, String Value) {
		

		if (isElementPresent(element)) {
			element.sendKeys(Value);
				}
		}
	
	
	// Wait for  element to be present 
	public static boolean isElementPresent(WebElement element) {
		boolean isPresent = false;		
		if (waitForElementToBePresent(element)) {
			
			isPresent = true;
		} else {
			
			System.out.println("Element is not present");

		}
		return isPresent;
	}
	
	
	public static boolean waitForElementToBePresent(final WebElement element) {
				
		Wait<WebElement> wait = new FluentWait<WebElement>(element).withTimeout(90, TimeUnit.SECONDS).pollingEvery(2,
				TimeUnit.SECONDS);

		Boolean elementDisplayed = wait.until(new Function<WebElement, Boolean>() {
			public Boolean apply(WebElement element) {
				return element.isDisplayed();
			}
		});
		return elementDisplayed;
	}
		
	
	
	//wait for page load
	public  void waitForPageLoad() {
		
		try {
			
			ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
				@Override
				public Boolean apply(WebDriver driver) {
					return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
				}
			};

			WebDriverWait wait = new WebDriverWait(getDriver(), 120);
			wait.until(pageLoadCondition);	

			
		} catch (Exception e) {
			
		}
	}
	
	public static void wait(final int sec) {
		try {
		Thread.sleep(sec*1000);
		}catch(Exception e) {
			System.out.println("Exception in wait");
		}
	}
	
	

	// *SCROLL DOWN
	// *********************************************************************************/
	public void GenericScrollDown() throws InterruptedException {
		JavascriptExecutor jse = (JavascriptExecutor) getDriver();
		jse.executeScript("window.scrollBy(0,450)", "");
		Thread.sleep(2000);
	}

	// *SCROLL UP
	// *********************************************************************************/
	public void GenericScrollUP() throws InterruptedException {
		JavascriptExecutor jse = (JavascriptExecutor) getDriver();
		jse.executeScript("window.scrollBy(0,-450)", "");
		Thread.sleep(2000);
	}

	// *DRAG AND DROP
	// *********************************************************************************/
	public SeleniumFunctions Drag_And_Drop(WebElement sourceElementName, WebElement targetElementName) {
		(new Actions(getDriver())).dragAndDrop(sourceElementName, targetElementName).perform();
		return this;
	}

	// *GET CURRENT
	// URL********************************************************************************/
	public String Current_URL() {
		String Current_URL = getDriver().getCurrentUrl();
		return Current_URL;
	}

	// *DOUBLE
	// CLICK***********************************************************************************/
	public void DoubleClick(WebElement ElementName) throws InterruptedException {
		Boolean iselementpresent = ElementName.isDisplayed();
		if (iselementpresent.booleanValue() == true) {
			Actions DoubleClick = new Actions(getDriver());
			DoubleClick.moveToElement(ElementName).doubleClick().build().perform();
			Thread.sleep(2000);
		} else {
		}
	}

	// *GENERATE
	// ALERT****************************************************************************/
	public SeleniumFunctions Generate_Alert(String Alert_Text) {
		JavascriptExecutor javascript = (JavascriptExecutor) getDriver();
		javascript.executeScript("alert(Alert_Text);");
		return this;
	}

	// * SCROLL INTO
	// VIEW**************************************************************************/
	public SeleniumFunctions ScrollIntoView(WebElement elementName) {
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].scrollIntoView(true);", elementName);
		return this;
	}

	// *IMPLICIT WAIT
	// *****************************************************************************/
	public SeleniumFunctions Wait(long Seconds) {
		getDriver().manage().timeouts().implicitlyWait(Seconds, TimeUnit.SECONDS);
		return this;
	}
	
	public static String getNewWindow(WebDriver driver) {
		Set<String> windowId = driver.getWindowHandles();    // get  window id of current window
        Iterator<String> itererator = windowId.iterator();  
        
        String mainWinID = null ;
        String  newAdwinID = null;
        if(itererator.hasNext()) {
         mainWinID = itererator.next();
         newAdwinID = itererator.next();
        }
       
        return newAdwinID;
        
	}
}
