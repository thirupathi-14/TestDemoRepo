package clarra.clarra.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import net.thucydides.core.pages.PageObject;

public class CommonFunctions extends PageObject {

	public Properties testDataProp = new Properties();
	public Properties configprop = new Properties();

	String root = System.getProperty("user.dir");
	
	static String sheetName = "Config";

	// *****Common Functions for the
	// application***************************************/
	
	
	
	public void launch_clarra_portal_app() throws IOException, InterruptedException {
		
		TestSettings ts = TestSettings.getInstance();
		Properties config = ts.getConfigProp();		
		String URL = config.getProperty("clarra");
		getDriver().get(URL);
		Thread.sleep(10000);
		getDriver().manage().window().maximize();
		String s=getDriver().getTitle();
		System.out.println("Title of the page is"+ s);
		
		}
		

	

	public void launch_UW_Login_app() throws InterruptedException {
		TestSettings ts = TestSettings.getInstance();
		Properties config = ts.getConfigProp();
		String thisURL = config.getProperty("UW_URL");
		System.out.println("URL to launch " + thisURL);
		getDriver().get(thisURL);
		Thread.sleep(5000);

	}

	/*public Boolean waitForElementToAppear(final WebElement e) {

		Wait<WebElement> wait = new FluentWait<WebElement>(e).withTimeout(90, TimeUnit.SECONDS).pollingEvery(2,
				TimeUnit.SECONDS);

		Boolean elementDisplayed = wait.until(new Function<WebElement, Boolean>() {
			public Boolean apply(WebElement element) {
				return element.isDisplayed();
			}
		});
		return elementDisplayed;
	}*/
	
	public int getRowNo_for_testdata(String sheetName, String testflow, XLSReader XLS) {
		
		int Row_count=XLS.getRowCount(sheetName);
		int Row=0;
	
        loop:  
        for (int i=2;i<=Row_count; i++)  
        { 

           if (XLS.getCellData(sheetName, "TestDataFlows", i).equalsIgnoreCase(testflow))
               {
                   Row=i;   

                   break loop;
               }
        }   
	
		return Row;
		
	}

	public void updateTestDataProps(Properties props){
		try{
		
		File file = new File(root + "/testdata/TestData.properties");
		FileOutputStream out = new FileOutputStream(root + "/testdata/TestData.properties");
		
		props.store(out, null);
		out.close();
		
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}
	public void updateConfigProps(Properties props){
		try{
		
		File file = new File(root + "/testdata/config.properties");
		FileOutputStream out = new FileOutputStream(root + "/testdata/config.properties");
		
		props.store(out, null);
		out.close();
		
		}catch(IOException ie){
			ie.printStackTrace();
		}
	}
}
