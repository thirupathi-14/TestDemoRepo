package clarra.clarra.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

public class TestSettings {
	public static TestSettings instance;
	public static HashMap<String, String> _inputMap;
	public static Properties configprop = new Properties();
	public static Properties testDataProp = new Properties();
	static String root = System.getProperty("user.dir");

	
	static String sheetName = "URLDetails";

	public static TestSettings getInstance() {
		if (instance == null) {
			instance = new TestSettings();
		}
		return instance;
	}

	// ************LOAD Credentials Properties file
	public static void loadCredentialsProperties() {
		try {
			
			FileInputStream fs = new FileInputStream(root + "/configuration/Config.properties");
			configprop.load(fs);
			
			FileInputStream dataFile = new FileInputStream(root + "/testdata/TestData.properties");
			testDataProp.load(dataFile);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
   
   static {
  
		
		XLSReader XLS = new XLSReader(root + "/testdata/ExcelData.xlsx");
		int rownum=XLS.getRowCount(sheetName);
		
		 Properties props = new Properties();
		 FileOutputStream out = null;
		for(int i=0;i<=rownum;i++) {
			String Execute =XLS.getCellData(sheetName, "Execute", i);
		     props.setProperty("Execute",Execute );
		     if(Execute.equalsIgnoreCase("Y")) {
		
		
		 String URL=XLS.getCellData(sheetName, "clarra", i);
		 props.setProperty("clarra",URL );
	     
	     
	    
		 
		 String IE_Driver_Path=XLS.getCellData(sheetName, "IE_Driver_Path", i);
		 props.setProperty("IE_Driver_Path",IE_Driver_Path );
		 
		 String Chrome_Driver_Path=XLS.getCellData(sheetName, "Chrome_Driver_Path", i);
		 props.setProperty("Chrome_Driver_Path",Chrome_Driver_Path );
	    
		 try {
			 out = new FileOutputStream(root + "/configuration/Config.properties");
			props.store(out, null);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		     }}
	}
	
	
	public TestSettings() {
		loadCredentialsProperties();
	}

	public Properties getConfigProp() {
		return configprop;
	}
	public Properties getTestDataProp() {
		return testDataProp;
	}

	public static void main(String[] args) throws IOException {
		TestSettings ts = TestSettings.getInstance();
	}
}
